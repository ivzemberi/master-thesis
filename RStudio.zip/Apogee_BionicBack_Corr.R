# Load necessary libraries
library(tidyverse)
library(corrplot)
library(rstatix)

# Load your data
raw_data <- read.csv(file.choose())

# Function to calculate correlation p-value matrix
cor_pmat_manual <- function(data, method = "spearman") {
  mat <- matrix(NA, ncol = ncol(data), nrow = ncol(data))
  colnames(mat) <- colnames(data)
  rownames(mat) <- colnames(data)
  
  for(i in 1:ncol(data)) {
    for(j in 1:ncol(data)) {
      if(i != j) {
        test <- cor.test(data[,i], data[,j], method = method, exact = FALSE)
        mat[i,j] <- test$p.value
      }
    }
  }
  return(mat)
}

# --- APOGEE CORRELATION MATRIX ---

apogee_data <- raw_data %>%
  select(
    PriorExp_Exoskeletons, 
    PriorExp_ClimbingGears, 
    PriorExp_SafetyHarness, 
    PriorExp_None, 
    PriorExp_Other,
    SEQ = Apogee.SEQ,
    `NASA-TLX` = Apogee.NASA,
    SUS = Apogee.SUS,
    UEQ = Apogee.UEQ,
    `Don Time` = Apogee.Don.Time,
    `Act Time` = Apogee.Activation.Time,
    `Doff Time` = Apogee.Doff.Time,
    Competence = Apogee.Competence.Score,
    Confidence = Apogee.Confidence.Score,
    Overall = Apogee.Overall.Score
  ) %>%
  mutate(across(everything(), ~as.numeric(gsub(",", "", as.character(.x)))))

zero_var_apogee <- apogee_data %>%
  summarise(across(everything(), ~var(.x, na.rm = TRUE))) %>%
  pivot_longer(everything()) %>%
  filter(value == 0 | is.na(value))

if(nrow(zero_var_apogee) > 0) {
  apogee_data <- apogee_data %>%
    select(-all_of(zero_var_apogee$name))
}

R_apogee <- cor(apogee_data, method = "spearman", use = "pairwise.complete.obs")
P_apogee <- cor_pmat_manual(apogee_data, method = "spearman")

# Rename labels
rename_labels_device <- function(x) {
  if(x == "PriorExp_Exoskeletons") return("Exp: Exo")
  if(x == "PriorExp_ClimbingGears") return("Exp: Climb")
  if(x == "PriorExp_SafetyHarness") return("Exp: Harness")
  if(x == "PriorExp_None") return("Exp: None")
  if(x == "PriorExp_Other") return("Exp: Other")
  return(x)
}

actual_names_apogee <- colnames(R_apogee)
new_names_apogee <- sapply(actual_names_apogee, rename_labels_device)

colnames(R_apogee) <- new_names_apogee
rownames(R_apogee) <- new_names_apogee
colnames(P_apogee) <- new_names_apogee
rownames(P_apogee) <- new_names_apogee


# --- BIONICBACK CORRELATION MATRIX ---

bionicback_data <- raw_data %>%
  select(
    PriorExp_Exoskeletons, 
    PriorExp_ClimbingGears, 
    PriorExp_SafetyHarness, 
    PriorExp_None, 
    PriorExp_Other,
    SEQ = BionicBack.SEQ,
    `NASA-TLX` = BionicBack.NASA,
    SUS = BionicBack.SUS,
    UEQ = BionicBack.UEQ,
    `Don Time` = BionicBack.Don.Time,
    `Act Time` = BionicBack.Activation.Time,
    `Doff Time` = BionicBack.Doff.Time,
    Competence = BionicBack.Competence.Score,
    Confidence = BionicBack.Confidence.Score,
    Overall = BionicBack.Overall.Score
  ) %>%
  mutate(across(everything(), as.numeric))

zero_var_bb <- bionicback_data %>%
  summarise(across(everything(), ~var(.x, na.rm = TRUE))) %>%
  pivot_longer(everything()) %>%
  filter(value == 0 | is.na(value))

if(nrow(zero_var_bb) > 0) {
  bionicback_data <- bionicback_data %>%
    select(-all_of(zero_var_bb$name))
}

R_bb <- cor(bionicback_data, method = "spearman", use = "pairwise.complete.obs")
P_bb <- cor_pmat_manual(bionicback_data, method = "spearman")

actual_names_bb <- colnames(R_bb)
new_names_bb <- sapply(actual_names_bb, rename_labels_device)

colnames(R_bb) <- new_names_bb
rownames(R_bb) <- new_names_bb
colnames(P_bb) <- new_names_bb
rownames(P_bb) <- new_names_bb


# --- Define consistent order for both matrices ---
consistent_order <- colnames(R_apogee)

# Reorder BionicBack matrix to match Apogee
R_bb <- R_bb[consistent_order, consistent_order]
P_bb <- P_bb[consistent_order, consistent_order]


# --- SAVE PLOTS ---

pdf("new_apogee.pdf", width = 10, height = 10)
corrplot(
  R_apogee,
  p.mat = P_apogee,
  method = "color",
  type = "upper",
  order = "original",
  sig.level = 0.05,
  insig = "n",
  diag = FALSE,
  addCoef.col = "black",
  tl.col = "black",
  tl.srt = 45,
  tl.cex = 1.3,
  number.cex = 1.0,
  cl.cex = 1.3,
  title = "",
  mar = c(0, 0, 0, 0)
)
dev.off()

print("Apogee matrix saved!")

pdf("new_bionicback.pdf", width = 10, height = 10)
corrplot(
  R_bb,
  p.mat = P_bb,
  method = "color",
  type = "upper",
  order = "original",
  sig.level = 0.05,
  insig = "n",
  diag = FALSE,
  addCoef.col = "black",
  tl.col = "black",
  tl.srt = 45,
  tl.cex = 1.3,
  number.cex = 1.0,
  cl.cex = 1.3,
  title = "",
  mar = c(0, 0, 0, 0)
)
dev.off()

print("BionicBack matrix saved!")

