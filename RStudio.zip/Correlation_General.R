# Load necessary libraries
library(tidyverse)
library(corrplot)
library(rstatix) 

# Load your CSV file
raw_data_60_trials <- read_csv("Corr_Long.csv") 

# Select the numeric columns for correlation
correlation_data_wide <- raw_data_60_trials %>%
  select(
    Age, 
    PriorExp_Exoskeletons, PriorExp_ClimbingGears, 
    PriorExp_SafetyHarness, PriorExp_None, PriorExp_Other,
    `Mean ATI Score`,
    SEQ, `NASA-TLX`, SUS, `UEQ-S`,
    `Donning Time`, `Activation Time`, `Doffing Time`, 
    `Competence Score`, `Confidence Score`, `Overall Score`
  ) %>%
  mutate(across(everything(), as.numeric))

# Remove zero-variance columns
zero_variance_cols <- correlation_data_wide %>%
  summarise(across(everything(), ~var(.x, na.rm = TRUE))) %>%
  pivot_longer(everything()) %>%
  filter(value == 0 | is.na(value))

if(nrow(zero_variance_cols) > 0) {
  correlation_data_final <- correlation_data_wide %>%
    select(-all_of(zero_variance_cols$name))
} else {
  correlation_data_final <- correlation_data_wide
}


print("Variables in your data:")
print(colnames(correlation_data_final))

# Calculate correlation matrices
method_corr <- "spearman"
use_setting <- "pairwise.complete.obs"

R_matrix <- cor(correlation_data_final, method = method_corr, use = use_setting)
P_matrix <- cor_pmat(correlation_data_final, method = method_corr)

# CONVERT P_matrix properly
P_matrix <- P_matrix %>%
  select(-rowname) %>%
  as.matrix()

# create mapping only for variables that exist
actual_names <- colnames(R_matrix)
new_names <- sapply(actual_names, function(x) {
  if(x == "Age") return("Age")
  if(x == "PriorExp_Exoskeletons") return("Exp: Exo")
  if(x == "PriorExp_ClimbingGears") return("Exp: Climb")
  if(x == "PriorExp_SafetyHarness") return("Exp: Harness")
  if(x == "PriorExp_None") return("Exp: None")
  if(x == "PriorExp_Other") return("Exp: Other")
  if(x == "Mean ATI Score") return("ATI")
  if(x == "SEQ") return("SEQ")
  if(x == "NASA-TLX") return("NASA-TLX")
  if(x == "SUS") return("SUS")
  if(x == "UEQ-S") return("UEQ")
  if(x == "Donning Time") return("Don Time")
  if(x == "Activation Time") return("Act Time")
  if(x == "Doffing Time") return("Doff Time")
  if(x == "Competence Score") return("Competence")
  if(x == "Confidence Score") return("Confidence")
  if(x == "Overall Score") return("Overall")
  return(x)  # Keep original if no match
})

# Apply renamed labels
colnames(R_matrix) <- new_names
rownames(R_matrix) <- new_names
colnames(P_matrix) <- new_names
rownames(P_matrix) <- new_names

# NOW SAVE TO PDF
pdf("correlation_matrix_general_big3.pdf", width = 12, height = 12)

corrplot(
  R_matrix,
  p.mat = P_matrix,
  method = "color",
  type = "upper",
  order = "hclust",
  sig.level = c(0.001, 0.01, 0.05),
  insig = "n",
  pch.cex = 0.9,
  diag = FALSE,
  addCoef.col = "black",
  tl.col = "black",
  tl.srt = 45,
  tl.cex = 1.3,
  number.cex = 1.0,
  cl.cex = 1.3,
  #title = "Spearman Correlation Matrix (All Trials, N=60)",
  mar = c(0, 0, 0, 0)
)

dev.off()

print("PDF saved successfully!")

